<!DOCTYPE html>

<html lang="en-US" xmlns:fb="http://ogp.me/ns/fb#" xmlns:addthis="http://www.addthis.com/help/api-spec"  prefix="og: http://ogp.me/ns#">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="http://www.astrospiritrc.com/xmlrpc.php">

<title>Page not found - Astro Spirit</title>

<!-- This site is optimized with the Yoast SEO plugin v4.0.2 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="noindex,follow"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="object" />
<meta property="og:title" content="Page not found - Astro Spirit" />
<meta property="og:site_name" content="Astro Spirit" />
<meta name="twitter:card" content="summary" />
<meta name="twitter:title" content="Page not found - Astro Spirit" />
<!-- / Yoast SEO plugin. -->

<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Astro Spirit &raquo; Feed" href="http://www.astrospiritrc.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Astro Spirit &raquo; Comments Feed" href="http://www.astrospiritrc.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.astrospiritrc.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.2"}};
			!function(a,b,c){function d(a){var b,c,d,e,f=String.fromCharCode;if(!k||!k.fillText)return!1;switch(k.clearRect(0,0,j.width,j.height),k.textBaseline="top",k.font="600 32px Arial",a){case"flag":return k.fillText(f(55356,56826,55356,56819),0,0),!(j.toDataURL().length<3e3)&&(k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,65039,8205,55356,57096),0,0),b=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55356,57331,55356,57096),0,0),c=j.toDataURL(),b!==c);case"emoji4":return k.fillText(f(55357,56425,55356,57341,8205,55357,56507),0,0),d=j.toDataURL(),k.clearRect(0,0,j.width,j.height),k.fillText(f(55357,56425,55356,57341,55357,56507),0,0),e=j.toDataURL(),d!==e}return!1}function e(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var f,g,h,i,j=b.createElement("canvas"),k=j.getContext&&j.getContext("2d");for(i=Array("flag","emoji4"),c.supports={everything:!0,everythingExceptFlag:!0},h=0;h<i.length;h++)c.supports[i[h]]=d(i[h]),c.supports.everything=c.supports.everything&&c.supports[i[h]],"flag"!==i[h]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[i[h]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(g=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",g,!1),a.addEventListener("load",g,!1)):(a.attachEvent("onload",g),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),f=c.source||{},f.concatemoji?e(f.concatemoji):f.wpemoji&&f.twemoji&&(e(f.twemoji),e(f.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='pirate_forms_front_styles-css'  href='http://www.astrospiritrc.com/wp-content/plugins/pirate-forms/css/front.css?ver=4.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='page-list-style-css'  href='http://www.astrospiritrc.com/wp-content/plugins/sitemap/css/page-list.css?ver=4.3' type='text/css' media='all' />
<link rel='stylesheet' id='default-icon-styles-css'  href='http://www.astrospiritrc.com/wp-content/plugins/svg-vector-icon-plugin/public/../admin/css/wordpress-svg-icon-plugin-style.min.css?ver=4.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='spu-public-css-css'  href='http://www.astrospiritrc.com/wp-content/plugins/popups/public/assets/css/public.css?ver=1.6.0.1' type='text/css' media='all' />
<link rel='stylesheet' id='zerif_font-css'  href='//fonts.googleapis.com/css?family=Lato%3A300%2C400%2C700%2C400italic%7CMontserrat%3A400%2C700%7CHomemade+Apple&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='zerif_font_all-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A400%2C300%2C300italic%2C400italic%2C600italic%2C600%2C700%2C700italic%2C800%2C800italic&#038;ver=4.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='zerif_bootstrap_style-css'  href='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/css/bootstrap.css?ver=4.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='zerif_fontawesome-css'  href='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/css/font-awesome.min.css?ver=v1' type='text/css' media='all' />
<link rel='stylesheet' id='zerif_style-css'  href='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/style.css?ver=v1' type='text/css' media='all' />
<link rel='stylesheet' id='zerif_responsive_style-css'  href='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/css/responsive.css?ver=v1' type='text/css' media='all' />
<!--[if lt IE 9]>
<link rel='stylesheet' id='zerif_ie_style-css'  href='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/css/ie.css?ver=v1' type='text/css' media='all' />
<![endif]-->
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script><script>jQueryWP = jQuery;</script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/plugins/dropdown-menu-widget/scripts/include.js?ver=4.7.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var pirateFormsObject = {"errors":""};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/plugins/pirate-forms/js/scripts-general.js?ver=4.7.2'></script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/plugins/top-bar/js/jquery.cookie.js?ver=4.7.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var tpbr_settings = {"fixed":"notfixed","message":"Email - <a href=\"mailto:dr.shalinibehl@astrospiritrc.com\"><span style=\"color:blue\">dr.shalinibehl@astrospiritrc.com<\/span><\/a> or Contact<a href=\"tel:+91 8527499691\"><span style=\"color:blue\">+91 8527499691<\/span><\/a>","status":"active","yn_button":"nobutton","color":"#F7DA64","button_text":"","button_url":"","close_image":null,"is_admin_bar":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/plugins/top-bar/js/tpbr_front.min.js?ver=4.7.2'></script>
<!--[if lt IE 9]>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/js/html5.js?ver=4.7.2'></script>
<![endif]-->
<link rel='https://api.w.org/' href='http://www.astrospiritrc.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.astrospiritrc.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.astrospiritrc.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.7.2" />


<!-- Dropdown Menu Widget Styles by shailan (http://shailan.com) v1.9.4 on wp4.7.2 -->
<link rel="stylesheet" href="http://www.astrospiritrc.com/wp-content/plugins/dropdown-menu-widget/css/shailan-dropdown.min.css" type="text/css" />
<link rel="stylesheet" href="http://www.astrospiritrc.com/wp-content/plugins/dropdown-menu-widget/themes/web20.css" type="text/css" />
<style type="text/css" media="all">
	ul.dropdown { white-space: nowrap; }
ul.dropdown li.parent>a{
	padding-right:25px;
}
ul.dropdown li.parent>a:after{ 
	content:""; position:absolute; top: 45%; right:6px;width:0;height:0; 
	border-top:4px solid rgba(0,0,0,0.5);border-right:4px solid transparent;border-left:4px solid transparent }
ul.dropdown li.parent:hover>a:after{
	content:"";position:absolute; top: 45%; right:6px; width:0; height:0;
	border-top:4px solid rgba(0,0,0,0.5);border-right:4px solid transparent;border-left:4px solid transparent }
ul.dropdown li li.parent>a:after{
	content:"";position:absolute;top: 40%; right:5px;width:0;height:0;
	border-left:4px solid rgba(0,0,0,0.5);border-top:4px solid transparent;border-bottom:4px solid transparent }
ul.dropdown li li.parent:hover>a:after{
	content:"";position:absolute;top: 40%; right:5px;width:0;height:0;
	border-left:4px solid rgba(0,0,0,0.5);border-top:4px solid transparent;border-bottom:4px solid transparent }


</style>
<!-- /Dropdown Menu Widget Styles -->

 <style type="text/css" id="custom-background-css">
body.custom-background { background-image: url("http://www.astrospiritrc.com/wp-content/uploads/2016/07/astro2.jpg"); background-position: left top; background-size: auto; background-repeat: repeat; background-attachment: scroll; }
</style>
<link rel="icon" href="http://www.astrospiritrc.com/wp-content/uploads/2016/07/cropped-fevicon-32x32.jpg" sizes="32x32" />
<link rel="icon" href="http://www.astrospiritrc.com/wp-content/uploads/2016/07/cropped-fevicon-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://www.astrospiritrc.com/wp-content/uploads/2016/07/cropped-fevicon-180x180.jpg" />
<meta name="msapplication-TileImage" content="http://www.astrospiritrc.com/wp-content/uploads/2016/07/cropped-fevicon-270x270.jpg" />

</head>


	<body class="error404" >



<div id="mobilebgfix">
	<div class="mobile-bg-fix-img-wrap">
		<div class="mobile-bg-fix-img"></div>
	</div>
	<div class="mobile-bg-fix-whole-site">


<header id="home" class="header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">

	<div id="main-nav" class="navbar navbar-inverse bs-docs-nav" role="banner">

		<div class="container">

			<div class="navbar-header responsive-logo">

				<button class="navbar-toggle collapsed" type="button" data-toggle="collapse" data-target=".bs-navbar-collapse">

				<span class="sr-only">Toggle navigation</span>

				<span class="icon-bar"></span>

				<span class="icon-bar"></span>

				<span class="icon-bar"></span>

				</button>

				<a href="http://www.astrospiritrc.com/" class="navbar-brand"><img src="http://www.astrospiritrc.com/wp-content/uploads/2016/07/astrology1_logo_mini.png" alt="Astro Spirit"></a>
			</div>

				<nav class="navbar-collapse bs-navbar-collapse collapse" id="site-navigation" itemscope itemtype="http://schema.org/SiteNavigationElement">
		<a class="screen-reader-text skip-link" href="#content">Skip to content</a>
		<ul id="menu-main-menu" class="nav navbar-nav navbar-right responsive-nav main-nav-list"><li id="menu-item-649" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-649"><a href="http://www.astrospiritrc.com/diwali-lakshmi-poojan/">Diwali Lakshmi Poojan</a></li>
<li id="menu-item-16" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16"><a href="http://www.astrospiritrc.com/courses/">Courses</a>
<ul class="sub-menu">
	<li id="menu-item-149" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-149"><a href="http://www.astrospiritrc.com/courses/#1">Astrology</a></li>
	<li id="menu-item-150" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-150"><a href="http://www.astrospiritrc.com/courses/#2">Numerlogy</a></li>
	<li id="menu-item-151" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-151"><a href="http://www.astrospiritrc.com/courses/#3">Tarot Cards</a></li>
	<li id="menu-item-163" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-163"><a href="http://www.astrospiritrc.com/courses/#4">Vastushashtra</a></li>
	<li id="menu-item-164" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-164"><a href="http://www.astrospiritrc.com/courses/#5">KP (Nadi)</a></li>
	<li id="menu-item-165" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-165"><a href="http://www.astrospiritrc.com/courses/#6">Healing &#038; Meditatation</a></li>
</ul>
</li>
<li id="menu-item-91" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-91"><a href="http://www.astrospiritrc.com/services/">Services</a></li>
<li id="menu-item-134" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-134"><a href="http://www.astrospiritrc.com/#latestnews">Blog</a>
<ul class="sub-menu">
	<li id="menu-item-564" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-564"><a href="http://www.astrospiritrc.com/category/thought-of-the-day/">Thought of the day</a></li>
	<li id="menu-item-565" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-565"><a href="http://www.astrospiritrc.com/category/horoscope/">Horoscope</a></li>
	<li id="menu-item-566" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-566"><a href="http://www.astrospiritrc.com/category/festival/">Festival Special</a></li>
</ul>
</li>
<li id="menu-item-208" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-208"><a href="http://www.astrospiritrc.com/contact-us/">Contact Us</a></li>
<li id="menu-item-522" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-522"><a href="http://www.astrospiritrc.com/category/horoscope/">Horoscope</a></li>
</ul>	</nav>
	
		</div>

	</div>
	<!-- / END TOP BAR -->
<div class="clear"></div>

</header> <!-- / END HOME SECTION  -->


<div id="content" class="site-content">

	<div class="container">

		<div class="content-left-wrap col-md-9">

			<div id="primary" class="content-area">

				<main id="main" class="site-main">

					<article>

						<header class="entry-header">

							<h1 class="entry-title">Oops! That page can&rsquo;t be found.</h1>
						</header><!-- .entry-header -->

						<div class="entry-content">

							<p>It looks like nothing was found at this location. Maybe try one of the links below or a search?</p>
						</div><!-- .entry-content -->

					</article><!-- #post-## -->

				</main><!-- #main -->

			</div><!-- #primary -->

		</div>

			<div class="sidebar-wrap col-md-3 content-left-wrap">
			<div id="secondary" class="widget-area" role="complementary">				<aside id="nav_menu-2" class="widget widget_nav_menu"><div class="menu-main-menu-container"><ul id="menu-main-menu-1" class="menu"><li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-649"><a href="http://www.astrospiritrc.com/diwali-lakshmi-poojan/">Diwali Lakshmi Poojan</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-16"><a href="http://www.astrospiritrc.com/courses/">Courses</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-149"><a href="http://www.astrospiritrc.com/courses/#1">Astrology</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-150"><a href="http://www.astrospiritrc.com/courses/#2">Numerlogy</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-151"><a href="http://www.astrospiritrc.com/courses/#3">Tarot Cards</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-163"><a href="http://www.astrospiritrc.com/courses/#4">Vastushashtra</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-164"><a href="http://www.astrospiritrc.com/courses/#5">KP (Nadi)</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-165"><a href="http://www.astrospiritrc.com/courses/#6">Healing &#038; Meditatation</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-91"><a href="http://www.astrospiritrc.com/services/">Services</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-134"><a href="http://www.astrospiritrc.com/#latestnews">Blog</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-564"><a href="http://www.astrospiritrc.com/category/thought-of-the-day/">Thought of the day</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-565"><a href="http://www.astrospiritrc.com/category/horoscope/">Horoscope</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-566"><a href="http://www.astrospiritrc.com/category/festival/">Festival Special</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-208"><a href="http://www.astrospiritrc.com/contact-us/">Contact Us</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-522"><a href="http://www.astrospiritrc.com/category/horoscope/">Horoscope</a></li>
</ul></div></aside>		<aside id="recent-posts-2" class="widget widget_recent_entries">		<h2 class="widget-title">Recent Posts</h2>		<ul>
					<li>
				<a href="http://www.astrospiritrc.com/diwali-lakshmi-poojan/">Diwali Lakshmi Poojan</a>
						</li>
					<li>
				<a href="http://www.astrospiritrc.com/importance-of-karvachauth/">Importance of karvachauth</a>
						</li>
					<li>
				<a href="http://www.astrospiritrc.com/karvachauth-special/">Karvachauth Special</a>
						</li>
					<li>
				<a href="http://www.astrospiritrc.com/ganesh-chaturthi/">Ganesh Chaturthi</a>
						</li>
					<li>
				<a href="http://www.astrospiritrc.com/thought-of-the-day-4/">Thought Of The Day</a>
						</li>
				</ul>
		</aside>		<aside id="archives-2" class="widget widget_archive"><h2 class="widget-title">Archives</h2>		<ul>
			<li><a href='http://www.astrospiritrc.com/2016/10/'>October 2016</a></li>
	<li><a href='http://www.astrospiritrc.com/2016/09/'>September 2016</a></li>
	<li><a href='http://www.astrospiritrc.com/2016/08/'>August 2016</a></li>
	<li><a href='http://www.astrospiritrc.com/2016/07/'>July 2016</a></li>
		</ul>
		</aside>			</div><!-- #secondary -->		</div><!-- .sidebar-wrap -->
	
	</div><!-- .container -->


</div><!-- .site-content -->


<footer id="footer" itemscope="itemscope" itemtype="http://schema.org/WPFooter">

	<div class="footer-widget-wrap"><div class="container"><div class="footer-widget col-xs-12 col-sm-4"><aside id="weblizar_facebook_likebox-4" class="widget footer-widget-footer widget_weblizar_facebook_likebox"><h1 class="widget-title">Like us on Facebook</h1>		<style>
		@media (max-width:767px) {
			.fb_iframe_widget {
				width: 100%;
			}
			.fb_iframe_widget span {
				width: 100% !important;
			}
			.fb_iframe_widget iframe {
				width: 100% !important;
			}
			._8r {
				margin-right: 5px;
				margin-top: -4px !important;
			}
		}
		</style>
        <div style="display:block;width:100%;float:left;overflow:hidden;margin-bottom:20px">
			<div id="fb-root"></div>
			<script>(function(d, s, id) {
			  var js, fjs = d.getElementsByTagName(s)[0];
			  if (d.getElementById(id)) return;
			  js = d.createElement(s); js.id = id;
			  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.4";
			  fjs.parentNode.insertBefore(js, fjs);
			}(document, 'script', 'facebook-jssdk'));</script>
			<div class="fb-like-box" style="background-color: auto;" data-small-header="true" data-height="300" data-href="https://www.facebook.com/astrospiritrc/" data-show-border="true" data-show-faces="true" data-stream="false" data-width="350" data-force-wall="false"></div>
			<div style="display:none;">Facebook By Weblizar Powered By Weblizar</div>
		</div>
        </aside></div></div></div>
	<div class="container">

		
		<div class="col-md-3 company-details"><div class="icon-top red-text"><img src="http://www.astrospiritrc.com/wp-content/uploads/2016/07/map-pointer.png" alt="" /></div><div class="zerif-footer-address">For Appointment
<br />
<a style="color: #e9e9e9" href="http://www.astrospiritrc.com/contact-us/">click here</a></div></div><div class="col-md-3 company-details"><div class="icon-top green-text"><img src="http://www.astrospiritrc.com/wp-content/uploads/2016/07/E-Mail-Icon.png" alt="" /></div><div class="zerif-footer-email"><a href="mailto:dr.shalinibehl@astrospiritrc.com">dr.shalinibehl@astrospiritrc.com</a></div></div><div class="col-md-3 company-details"><div class="icon-top blue-text"><img src="http://www.astrospiritrc.com/wp-content/uploads/2016/07/wa-icon.png" alt="" /></div><div class="zerif-footer-phone"><a href="tel:+91 8527499691">+91 8527499691</a></div></div><div class="col-md-3 copyright"><ul class="social"><li><a target="_blank" href="https://www.facebook.com/astrospiritrc"><i class="fa fa-facebook"></i></a></li><li><a target="_blank" href="https://www.instagram.com/astro_spirit/"><i class="fa fa-instagram"></i></a></li></ul><p id="zerif-copyright"> ©Astrospiritrc.com</p><div class="zerif-copyright-box"><a class="zerif-copyright" href="" target="_blank" rel="nofollow">AstroSpirit </a>Developed by<a class="zerif-copyright" href="" target="_blank" rel="nofollow"> TEDCAM</a></div></div>			</div> <!-- / END CONTAINER -->

</footer> <!-- / END FOOOTER  -->


	</div><!-- mobile-bg-fix-whole-site -->
</div><!-- .mobile-bg-fix-wrap -->


<!-- analytics-counter google analytics tracking code --><script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-81206931-1', 'auto');

    ga('set', 'anonymizeIp', true);    ga('send', 'pageview');

</script><!--  --><script data-cfasync="false" type="text/javascript">
var addthis_config = {"data_track_clickback":true,"ui_atversion":300,"ignore_server_config":true};
var addthis_share = {};
</script><link rel='stylesheet' id='addthis_output-css'  href='http://www.astrospiritrc.com/wp-content/plugins/addthis/css/output.css?ver=4.7.2' type='text/css' media='all' />
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-includes/js/hoverIntent.min.js?ver=1.8.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var spuvar = {"is_admin":"","disable_style":"","safe_mode":"1","ajax_mode":"1","ajax_url":"http:\/\/www.astrospiritrc.com\/wp-admin\/admin-ajax.php","ajax_mode_url":"http:\/\/www.astrospiritrc.com\/?spu_action=spu_load&lang=","pid":"0","is_front_page":"","is_category":"","site_url":"http:\/\/www.astrospiritrc.com","is_archive":"","is_search":"","seconds_confirmation_close":"5"};
var spuvar_social = [""];
/* ]]> */
</script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/plugins/popups/public/assets/js/min/public-min.js?ver=1.6.0.1'></script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/js/bootstrap.min.js?ver=20120206'></script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/js/jquery.knob.js?ver=20120206'></script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/js/smoothscroll.js?ver=20120206'></script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/js/scrollReveal.js?ver=20120206'></script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-content/themes/zerif-lite/js/zerif.js?ver=20120206'></script>
<script type='text/javascript' src='http://www.astrospiritrc.com/wp-includes/js/wp-embed.min.js?ver=4.7.2'></script>
<!--wp_footer-->

</body>

</html>